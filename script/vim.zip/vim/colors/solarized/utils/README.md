These are used only for testing and packaging Solarized into release formats.  
Disregard unless you are into ugly ex and quick and dirty shell scripts.
