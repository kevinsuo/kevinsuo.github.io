reset

# set the figure style
set term postscript enhanced color size 17cm, 7.5cm font 10

set style histogram rowstacked
set style data histograms                                                      

set output "| pstopdf -i -o output.pdf"

# set the layout
set multiplot layout 1,2
set style fill solid 1.00 border 0




# the left figure
#------------------------------------------------------

set size 0.5,1
set yrange [0:1000]

set title '(a) Sockperf average latency decomposition'

set ylabel "Latency ({/Symbol \155}s)"
set ylabel font ",10"


set grid y lw 2
set tics scale 0

set xtics nomirror rotate by -45 
set ytics nomirror 


set boxwidth 0.5 relative


#set key box
set key vertical top inside center autotitle columnhead
set key font ",10"
set key samplen 1


set tics font ",10"

plot '1.txt' using 2:xticlabels(1) fs solid lc rgb "#333333",  \
    '' using 3 fs solid lc rgb "#FFEB7F",  \
    '' using 4 fs solid lc rgb "#70C17E"



# the right figure
#-------------------------

set style histogram clustered gap 1.5
set style data histograms


set title '(b) Sockperf average and tail latency'
set ylabel "Latency ({/Symbol \155}s)"

set size 0.5,1

set grid y lw 2
set xtics nomirror rotate by -45

set xtics nomirror
set ytics nomirror


set format y "%.0e"


set key top right vertical inside 


set style fill solid 1 border 0
set yrange [0:30000]

ds = 1
set boxwidth ds absolute

plot '2.txt' using ($2):xtic(1) title col fs solid 0.8                   lt -1 lw 0.6,\
			  '' using ($3):xtic(1) title col fs solid lc rgb "#FFEB7F"  lt -1 lw 0.6,\
			  '' using ($4):xtic(1) title col fs solid lc rgb "#70C17E"  lt -1 lw 0.6


