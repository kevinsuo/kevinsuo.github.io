reset
set term postscript enhanced color size 17cm, 6cm font 10

                                                  
set output "| pstopdf -i -o output.pdf"
#set size 0.8,0.5 
set multiplot layout 1,2
set style fill solid 1.00 border 0


#-------------------------------

set size 0.47,1
set style data histogram
set style histogram rowstacked
set style fill solid border -1

set title "(a) aaa" font ",12"
set ylabel "aaaa" font ",12"


set grid y lw 2

#set grid y lw 2
set xtics nomirror 
set ytics nomirror


#set key top right vertical inside
set key top right vertical inside
#set key height 7
#set nokey

set style fill solid 1 border 0
#set size 0.5,0.37
set yrange [0:1.4]

ds = 1
set boxwidth ds absolute


plot newhistogram "aaa" font ",12"  offset 0,-1,    '1.txt'       using ($2/3442):xtic(1) title '1111' fs pattern 3 lc rgb "#FEA17A", '' using ($3/3442) title '2222' lc rgb "#00BFFF", \
	 newhistogram "aaaa" font ",12" offset 0,-1,    '2.txt'    using ($2/4021):xtic(1) notitle            		fs pattern 3 lc rgb "#FEA17A", '' using ($3/4021) notitle         lc rgb "#00BFFF"
#	 newhistogram "hibench.kmeans" offset 0,-1,    'kmeans.txt'    using ($2/1415):xtic(1) notitle            lc rgb "#FF7F50", '' using ($3/1415) notitle         lc rgb "#00BFFF"
#	 newhistogram "specjvm.compiler.compiler" offset 0,-1,    'compiler.compiler.txt'    using ($2/58.7337014):xtic(1) notitle            lc rgb "#FF7F50", '' using ($3/58.7337014) notitle         lc rgb "#00BFFF", \



#-------------------------------

set size 0.47,1


set title "(b) bbb" font ",12"
set ylabel "bbbb" font ",12"
#set y2label "Execution Time (sec) \n large dataset"

#set grid y lw 2
set xtics nomirror 
set ytics nomirror
#set y2tics


#set key top right vertical inside
set key top right vertical inside
#set key height 7
#set nokey

set style fill solid 1 border 0
#set size 0.5,0.37

#set logscale y
#set format y "%.0e"
set yrange [0:1.4]
#set y2range [0:1600]

ds = 1
set boxwidth ds absolute


plot newhistogram "bbb"  font ",12"  offset 0,-1,    '3.txt'       using ($2/57):xtic(1) title '1111' fs pattern 3 lc rgb "#FEA17A", '' using ($3/57) title '2222' lc rgb "#00BFFF", \
	 newhistogram "bbbb" font ",12" offset 0,-1,    '4.txt'    using ($2/1415):xtic(1) notitle            		fs pattern 3 lc rgb "#FEA17A", '' using ($3/1415) notitle         lc rgb "#00BFFF"
#	 newhistogram "hibench.kmeans" offset 0,-1,    'kmeans.txt'    using ($2/1415):xtic(1) notitle            lc rgb "#FF7F50", '' using ($3/1415) notitle         lc rgb "#00BFFF"
#	 newhistogram "specjvm.compiler.compiler" offset 0,-1,    'compiler.compiler.txt'    using ($2/58.7337014):xtic(1) notitle            lc rgb "#FF7F50", '' using ($3/58.7337014) notitle         lc rgb "#00BFFF", \




