reset
set term postscript enhanced color size 8cm, 6.6cm font 10.5

set view map
set tic scale 0

set title "bbb" font ",10.5"


set output "| pstopdf -i -o output.pdf"


set cbrange [0:10]
set cblabel "aaaaaa"


set palette rgb 33,13,10
set pm3d interpolate 10,10

set xrange [0:19]
set yrange [0:14]

set xlabel "xxx" 
set ylabel "yyy" 

splot '1.txt' matrix with pm3d

