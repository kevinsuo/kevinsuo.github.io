reset
set term postscript enhanced color size 22cm, 17cm font 10
set style data lines                                                    


set style fill solid 1.00 border 0
set output "| pstopdf -i -o output.pdf"
set multiplot layout 1,2


#-------------------------------

set size 0.5, 0.5
set xrange [0:100]
set yrange [0:100]

set title font ",16" 
set title "(a) aaa" offset -4,1
set xlabel "test" font ",16" 
set ylabel "Latency ({/Symbol \155}s)" font ",16" offset -2


set grid y lw 2
set xtics nomirror font ",16" 
#set xtic ("0" 0, "5" 5, "10" 10, "15" 15) font ",16" 
set xtic ("0" 0, "20" 20, "40" 40, "60" 60, "80" 80, "100" 100) font ",16" 


set ytics nomirror font ",16" 
#set ytic("12" 100,"13" 400)  font ",16" 

set key vertical right top font ",16"
set key spacing 1
set key samplen 2
set key width 2


plot "1.txt" using (($2+$3+$4+$5)/1000) t "aaa" w filledcurves x1 lc rgb "#fb6a4a" fs solid 1.00 border lc rgb "#fb6a4a",\
		 ""  using (($2+$3+$4)/1000) t "bbb" w filledcurves x1 lc rgb "#bae4bc" fs solid 1.00 border lc rgb "#bae4bc",\
		 ""  using (($2+$3)/1000)    t "ccc"  w filledcurves x1 lc rgb "#cb181d" fs solid 1.00 border lc rgb "#cb181d",\
		 ""  using (($2)/1000)         t "ddd" w filledcurves x1 lc rgb "#2b8cbe" fs solid 1.00 border lc rgb "#2b8cbe"




#-------------------------------

set size 0.5, 0.5
set xrange [0:100]
set yrange [0:2000]


set title font ",16" 
set title "(b) bbb" offset -1,1
set xlabel "test" font ",16" 
set ylabel "Latency ({/Symbol \155}s)" font ",16" offset -2


set grid y lw 2
set xtics nomirror 
set xtic ("0" 0, "20" 20, "40" 40, "60" 60, "80" 80, "100" 100) font ",16" 


set ytics nomirror

set key vertical right top font ",16"
set key spacing 1
set key samplen 2
set key width 2




plot "2.txt" using (($2+$3+$4+$5)/1000) t "aaa" w filledcurves x1 lc rgb "#fb6a4a" fs solid 1.00 border lc rgb "#fb6a4a",\
		 ""  using (($2+$3+$4)/1000) t "bbb" w filledcurves x1 lc rgb "#bae4bc" fs solid 1.00 border lc rgb "#bae4bc",\
		 ""  using (($2+$3)/1000)    t "ccc"  w filledcurves x1 lc rgb "#cb181d" fs solid 1.00 border lc rgb "#cb181d",\
		 ""  using (($2)/1000)         t "ddd" w filledcurves x1 lc rgb "#2b8cbe" fs solid 1.00 border lc rgb "#2b8cbe"




