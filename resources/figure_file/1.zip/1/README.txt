Execute the following command:

gnuplot draw.sh
