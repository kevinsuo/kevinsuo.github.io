reset

# set the figure size, type and output file
set term postscript enhanced color size 15cm, 6.3cm font 9.5
set style data linespoints                                                    
set output "| pstopdf -i -o output.pdf"

# set the layout as 1,2
set multiplot layout 1,2
set style fill solid 1.00 border 0

# set line style
set style line 1 linetype 1 linecolor rgb '#B40000' linewidth 2 pointtype 2 pointsize 1.1 dt 1   # --- blue
set style line 2 linetype 1 linecolor rgb '#a6611a' linewidth 2 pointtype 2 pointsize 1   # --- red
set style line 3 linetype 1 linecolor rgb '#009C24' linewidth 2 pointtype 65 pointsize 1 dt 2   # --- black
set style line 4 linetype 1 linecolor rgb '#a6d96a' linewidth 2 pointtype 12 pointsize 1   # --- black
set style line 5 linetype 1 linecolor rgb '#4654C9' linewidth 2 pointtype 1 pointsize 1.1 dt 3  # --- black



# the left figure
#-------------------------------
set size 0.5,1
set logscale y
set format y "%.0e"
set yrange [10:10000]
set xrange [1:7]


set xtics ('25%%' 1, '50%%' 2, '75%%' 3, '90%%' 4, '99%%' 5, '99.9%%' 6, '99.99%%' 7)
set xtics rotate by -30


set title '(a) Sockperf latency' offset -2,0.5

set ylabel "Latency ({/Symbol \155}s)"
set xlabel "Latency"


set grid y lw 2
set xtics nomirror 
set ytics nomirror 


set key top center vertical inside
set key samplen 2


plot '1.txt' using 1:2 with linespoints ls 1 title columnhead,\
 	     ''  using 1:3 with linespoints ls 5 title columnhead,\
	     ''  using 1:4 with linespoints ls 3 title columnhead



# set the right figure
#-------------------------------
set size 0.5,1
unset logscale y

set format y "%.1f"
set yrange [0:3]
set xrange [0:4]


set xtics ('Min' 0, 'Avg' 1, '90%%' 2, '95%%' 3, '99%%' 4)


set title '(b) Memcached latency' offset -2,0.5
set ylabel "Latency (ms)"
set xlabel "Latency"



set grid y lw 2
set xtics nomirror 
set ytics nomirror 


set key top right vertical inside



plot '2.txt' using 1:2 with linespoints ls 1 title columnhead,\
 	     ''  using 1:3 with linespoints ls 5 title columnhead,\
	     ''  using 1:4 with linespoints ls 3 title columnhead

