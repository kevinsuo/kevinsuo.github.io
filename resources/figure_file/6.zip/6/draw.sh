reset
set term postscript enhanced color size 22cm, 8cm font 10
set style data lines                                                    


set style fill solid 1.00 border 0
set output "| pstopdf -i -o output.pdf"
set multiplot layout 1,2


#-------------------------------

set size 0.5, 1
set xrange [0:12]
set yrange [0:2000]


set title font ",12" 
set title 'aaa' offset -3,1
set xlabel "xxx" font ",12" 
set ylabel "yyy" font ",12" offset -2


set grid y lw 2
set xtics nomirror 
set xtic ("0" 0, "2" 2, "4" 4, "6" 6, "8" 8, "10" 10, "12" 12) font ",12" 


set ytics nomirror font ",12" 

set key right top font ",12" 



plot "1.txt" using 2 w lines lt 1 lw 1 lc 7 t "ttt"


#-------------------------------

set size 0.5, 1
set xrange [0:240]
set yrange [0:2000]


set title font ",12" 
set title 'bbb' offset 1,1
set xlabel "xxx" font ",12" 
set ylabel "yyy" font ",12" offset -2


set grid y lw 2
set xtics nomirror 
set xtic ("0" 0, "2" 40, "4" 80, "6" 120, "8" 160, "10" 200, "12" 240) font ",12" 


set ytics nomirror
set key right top font ",12" 



plot "2.txt" using 2 w lines lt 1 lw 1 lc 7 t "ttt"


